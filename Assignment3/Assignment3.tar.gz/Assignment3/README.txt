Instructions for running program.  

1) Place the following files in the working directory together:
	-multi-lookup.c
	-multi-lookup.h
	-Make
	-util.h
	-util.c
	-input/ (folder for name files to be read)

2)Open terminal and go to working directory and run make.   

3)Input argument = ./multi-lookup <numberofrequestors> <numberofresolvers> <requestorlog> 
<resolverlogs> <namefilesyouwishtorun>