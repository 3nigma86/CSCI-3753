
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <pthread.h>
#include <unistd.h>
#include <stdbool.h>
#include "util.h"
#include "multi-lookup.h"

//condition variables
pthread_cond_t arrayFull;		
pthread_cond_t arrayEmpty;		 
//mutex locks
pthread_mutex_t arrayLock;		
pthread_mutex_t requestorLock;		
pthread_mutex_t resolverLock;


char hostname[SBUFSIZE][SBUFSIZE];
char firstipstr[INET6_ADDRSTRLEN];
char* outputFile; 									
int reqthreads, resthreads;
int reqstart, resstart = 0;			                	
FILE* inputfp = NULL;
FILE* results = NULL;
FILE* serviced = NULL;
char *argt[30];
char* argv[];

int main(int argc, char* argv[]){ 
	int i;
	int j;


	pthread_mutex_init(&arrayLock, NULL);
	pthread_mutex_init(&requestorLock,NULL);
	pthread_mutex_init(&resolverLock,NULL);
	pthread_cond_init(&arrayFull, NULL);
	pthread_cond_init(&arrayEmpty, NULL);
        pthread_t reqthread[reqthreads];
	pthread_t resthread[resthreads];

	printf("Ready to find IP addresses!!! \n\n\nHow many requester threads would you like to use?\n");
	scanf("%d", &reqthreads);
	printf("Great...  How many resolver threads?\n");
	scanf("%d", &resthreads);
	

	if (argc < MINARGS){
		fprintf(stderr, "Not enough arguments: %d", (argc-1));
		fprintf(stderr, "Usage:\n %s %s\n", argv[0], USAGE);
		return(EXIT_FAILURE);
	}
	
	
	results = fopen("results.txt", "w");
	if(!results){
		fprintf(stderr, "Error: Bogus output file path.\n");
		return (EXIT_FAILURE);
	}

	
	
	for (i = 0; i < reqthreads; i++){
		int producer = pthread_create(&reqthread[i], NULL, readFiles, argv[i+1]);
		if (producer){
			fprintf(stderr, "ERROR: return code from pthread_create() is %d\n", producer);
		}
	}
	
	
	for (i = 0; i < resthreads; i++){
		int consumer = pthread_create(&resthread[i], NULL, *dns, argv[9]) ;
		if(consumer){
			fprintf(stderr, "ERROR: return code from pthread_create() is %d\n", consumer);
		}
	}
	
	
	for (i = 0; i < reqthreads; i++){
		pthread_join(reqthread[i], NULL);
	}
	
	
	
	for (i = 0; i < resthreads; i++){
		pthread_join(resthread[i], NULL);
	}
	

	printf("File Processing Complete : %d", gettimeofday());
	
	
	
	fclose(inputfp);
	fclose(serviced);
	fclose(results);
	
	
	
	for(i = 0; i<21;i++){
		for (j=0; j<21;i++){
			strcpy(hostname[i][j],"0");
		}
	}
	
	
	pthread_mutex_destroy(&arrayLock);
	pthread_mutex_destroy(&requestorLock);
	pthread_mutex_destroy(&resolverLock);
	return EXIT_SUCCESS;

}			

void* readFiles(char* filename){
	char filePath[SBUFSIZE] = "input/";
	int i;
	bool finished = false;
	

	pthread_mutex_lock(&requestorLock);
	reqstart++;
	pthread_mutex_unlock(&requestorLock);
	strcat(filePath, filename);

	printf("%s\n", filePath);
	if(reqstart == 1){
	inputfp = fopen(filePath, "r");
	if(!inputfp){
		fprintf(stderr, "Error: Bogus input file path.\n");
		return NULL;
		}
	}
	
	printf("%d Read file thread\n", reqstart);
	if(reqstart == 1){
	serviced = fopen("serviced.txt","w");
	if(!serviced){
		fprintf(stderr, "Error: No serviced.txt found.\n");
		return NULL;
		}
	}
	while(!finished){
		for(i = 0; i < 20; i++){
			if(hostname[i][0] == '\0'){
				fscanf(inputfp,"%s",hostname[i]); 
				printf("%s\n",hostname[i]);
				break;
			}
		}
		if(feof(inputfp))
			finished=true;
	}
	return NULL;
}

void* dns(FILE* results) {
	int i;
	sleep(5);
	printf("%s", hostname[0]);
	fprintf(results, "%s\n",hostname);
	strcpy(firstipstr, "dude");
	for(i =0; i<5;i++){
		fprintf(results, "%s,%s\n", hostname[i],firstipstr);
	}
	/*while (hostname[0][0] != '\0'){
			if (dnslookup(hostname[0], firstipstr, sizeof(firstipstr))==UTIL_FAILURE){
				fprintf(stderr, "Error: DNS lookup failure on hostname: %s\n", hostname[0]);
				strncpy(firstipstr, "", sizeof(firstipstr));
		}
			else{
				fprintf(results, "%s,%s\n", hostname[i],firstipstr);
		}
			for(i = 0; i < 19 ; i++){
				strncpy(hostname[i], hostname[i+1], sizeof(hostname[i]));
		}

	}*/

		
	/*while(1){
		// lock queue mutex to access.
		pthread_mutex_lock(&bufferLock);
		// check to see if queue is empty
		while(queue_is_empty(&requestQ)){
			// ensure that we lock files completed counter variable to access.
			pthread_mutex_lock(&requestorLock);
			int finished = 0;
			// determine if we are at the end of the queue. 
			if(filesCompleted == numInputFiles) finished = 1;
			// unlock counter variable
			pthread_mutex_unlock(&requestorLock);
			// we are finished so unlock queue. 
			if (finished){
				// unlock queue mutex
				pthread_mutex_unlock(&bufferLock);
				return NULL;
			}
			// if the queue is empty but we still have files to consume that means that consumer threads must wait on condition variable emptyQueue.
			pthread_cond_wait(&queueEmpty, &queueLock);
		}
		// pop 1 hostname from the queue.
		char* hostname = 
		// let producer processes know that there is space in the queue.
		pthread_cond_signal(&bufferFull);
		if (dnslookup(hostname, firstipstr, sizeof(firstipstr))==UTIL_FAILURE){
			fprintf(stderr, "Error: DNS look failed, bogus hostname: %s\n", hostname);
			strncpy(firstipstr, "", sizeof(firstipstr));
		}
		// lock the output file using resolver mutex lock.
		pthread_mutex_lock(&resolverLock);
		fprintf(outputfp, "%s,%s\n", hostname, firstipstr); 
		pthread_mutex_unlock(&resolverLock);
		free(hostname);
		pthread_mutex_unlock(&bufferLock);
	}*/
	return NULL;
}

